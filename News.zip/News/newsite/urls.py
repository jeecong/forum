from django.conf.urls import url
from . import views
from . import newsViews

urlpatterns = [
	url(r"index",views.welcome),
	url(r'publogin',views.publisher_login),
	url(r'pubregister',views.publisher_register),
	url(r'ajaxhaddle',views.ajax_response),
	url(r'alterinfo',views.alter_info),
	url(r'publish',views.publish_news),
	url(r'delete',views.delete_news),
	url(r'newsIndex',newsViews.news_index)
]
