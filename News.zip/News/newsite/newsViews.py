#coding=utf-8
from django.shortcuts import render
from django.http import HttpResponse
from models import NewsModel,Publisher,PubHeader

def news_index(request):
	newsArr = NewsModel.objects.all()

	infoArr = []

	for news in newsArr:
		# 根据新闻外键，查找出该新闻对应的发布者的信息
		publisher = Publisher.objects.filter(id = news.publisher_id)[0]
		pubheader = PubHeader.objects.filter(id = news.publisher_id)[0]
		infoDict = {'news':news,'publisher':publisher,'pubheader':pubheader}
		infoArr.append(infoDict)

		pass

	context = {'newsArr':infoArr}

	return render(request,'newsindex.html',context)



