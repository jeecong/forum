#coding=utf-8
from django.shortcuts import render
from django.http import HttpResponse
from models import Publisher,PubHeader,NewsModel
import time

from django.conf import settings
import os

# Create your views here.

# 引导页函数
def welcome(request):

	return HttpResponse('欢迎大家来到波波老师的内涵社区')

#######【发布者模块】######## 
# 登录界面
def publisher_login(request):
	if request.method=='POST':
		# 接收登录界面表单的数据
		username = request.POST['username']
		password = request.POST['password']

		# 根据数据从数据库中查找用户
		userArr = Publisher.objects.filter(username=username)
		if userArr:
			# 说明用户名是正确的，进一步的比较密码是否正确
			# 从userArr列表中取出一个元素
			user = userArr[0]
			if user.password == password:
				# 说明密码正确，说明登录成功，就可以安装登录成功以后的模板
				# 查询自己已经发过的新闻
				newsArr = NewsModel.objects.filter(publisher_id=user.id)

				# 将当前查询到的对象转成字典
				userDict = {'id':user.id,'username':user.username,'nickname':user.nickname,'sex':user.sex,'signature':user.signature,'newsArr':newsArr}

				# 查询数据库中，头像的地址
				header = PubHeader.objects.filter(id_id=user.id)
				if len(header):
					headerimg = header[0]
					userDict['headerurl'] = headerimg.url.url

	
				# 构建一个模板上下文
				context = {}
				context['userinfo'] = userDict

			

				return render(request,'publisher/index.html',context)
				# return HttpResponse("登录成功！")
			else:
				# 说明密码不正确，直接给前端响应密码错误
				return HttpResponse("密码错误！")
		
		else:
			# 说明用户名不正确，该用户不存在,直接给前端响应用户名不存在
			return HttpResponse('用户名不存在！')

	# 安装模板
	return render(request,"publisher/login.html")

# 注册页面
def publisher_register(request):

	# 模板中发生提交事件以后要在下面的代码中处理
	if request.method=='POST':
		# 一旦发生post事件，则在这里处理
		# 接收前端提交的数据
		username = request.POST['username']
		password = request.POST['password']
		nickname = request.POST['nickname']
		sex = request.POST['sex']
		signture = request.POST['signture']
		# 处理前端提交的数据
		# 建模
		pub = Publisher(username=username,password=password,nickname=nickname,sex=sex,signature=signture)
		# 存入数据库
		pub.save()
		return HttpResponse("<script type='text/javascript'>alert('注册成功！');window.history.back();</script>")
		
	# 安装模板
	return render(request,"publisher/register.html")


# 修改个人信息
def alter_info(request):
	if request.method=='POST':
		if request.POST['flag']=='index':
			# 在这里安装修改个人信息的模板
			userid = request.POST['userid']
			# 根据userid查找出对象
			userArr = Publisher.objects.filter(id=userid)
			usr = userArr[0]

			# 转成字典
			userDict = {'id':usr.id,'nickname':usr.nickname,'signature':usr.signature,'password':usr.password}
			context = {'userinfo':userDict}

			return render(request,'publisher/alterinfo.html',context)
		else:
			# 说明不是index页发出的post请求，有可能是模板页，处理模板的post请求
			nickname = request.POST['nickname']
			signature = request.POST['signature']
			id = request.POST['userid']
			userArr = Publisher.objects.filter(id=id)
			usr = userArr[0]
			usr.nickname = nickname
			usr.signature = signature
			usr.save()

			# 先和原来的头像断绝关系（删除原来的图片）
			res = PubHeader.objects.filter(id_id=id)
			if len(res):
				src = (settings.BASE_DIR+res[0].url.url).replace('\\','/')
				os.remove(src)
				
			

			# 头像上传
			# 获取提交的头像
			img = request.FILES['headerimg']
			# 创建头像模型，id值依赖于发布者
			header = PubHeader(id_id=id,url=img)
			header.save()

			return HttpResponse('修改成功！')
			pass

	return HttpResponse("修改模板待安装...")


# 新闻发布功能
def publish_news(request):

	if request.POST['flag']=='index':

		id = request.POST['userid']

		return render(request,'publisher/publish.html',{'userid':id})
	else:
		userid = request.POST['userid']
		title = request.POST['title']
		kind = request.POST['kind']
		content = request.POST['content']
		# 生成一个当前时间，作为新闻发布的时间
		# timer = time.time() # time()方法生成距离1970年1月1日0：00:00过去了多少秒

		# timer = time.localtime()
		# 用时间戳生成一个时间
		timer = time.strftime("%Y-%m-%d %X",time.localtime())

		# 将提交数据存入数据库
		news = NewsModel(title=title,type=kind,time=timer,content=content,publisher_id=userid)
		news.save()

		return HttpResponse('<script type="text/javascript">alert("发布成功！");window.history.back();</script>')

		pass

	return HttpResponse('发布模板待安装...')



#########【公用模块】##########
# ajax请求的响应
def ajax_response(request):
	username = request.POST['username']
	# 查询前端传过来的用户名是否在数据库中
	res = Publisher.objects.filter(username=username)
	# 将查询的结果作为响应体返回
	return HttpResponse(res)

# 用ajax方式删除指定的新闻
def delete_news(request):
	newsid = request.POST['newsid']

	# 将指定的数据删除
	NewsModel.objects.filter(id=newsid).delete()

	return HttpResponse("OK")
	pass